<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="i will recover this shit at any cost" tilewidth="77" tileheight="63" tilecount="45" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="11" height="6" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Bushes/6.png"/>
 </tile>
 <tile id="1">
  <image width="26" height="20" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Bushes/1.png"/>
 </tile>
 <tile id="2">
  <image width="24" height="20" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Bushes/2.png"/>
 </tile>
 <tile id="3">
  <image width="14" height="13" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Bushes/3.png"/>
 </tile>
 <tile id="4">
  <image width="19" height="18" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Bushes/4.png"/>
 </tile>
 <tile id="5">
  <image width="18" height="14" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Bushes/5.png"/>
 </tile>
 <tile id="6">
  <image width="31" height="18" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Crystals/6.png"/>
 </tile>
 <tile id="7">
  <image width="57" height="46" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Crystals/1.png"/>
 </tile>
 <tile id="8">
  <image width="52" height="55" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Crystals/2.png"/>
 </tile>
 <tile id="9">
  <image width="77" height="63" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Crystals/3.png"/>
 </tile>
 <tile id="10">
  <image width="44" height="52" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Crystals/4.png"/>
 </tile>
 <tile id="11">
  <image width="22" height="31" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Crystals/5.png"/>
 </tile>
 <tile id="12">
  <image width="11" height="8" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Grass/10.png"/>
 </tile>
 <tile id="13">
  <image width="4" height="4" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Grass/1.png"/>
 </tile>
 <tile id="14">
  <image width="5" height="5" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Grass/2.png"/>
 </tile>
 <tile id="15">
  <image width="5" height="3" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Grass/3.png"/>
 </tile>
 <tile id="16">
  <image width="5" height="5" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Grass/4.png"/>
 </tile>
 <tile id="17">
  <image width="3" height="4" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Grass/5.png"/>
 </tile>
 <tile id="18">
  <image width="5" height="5" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Grass/6.png"/>
 </tile>
 <tile id="19">
  <image width="5" height="5" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Grass/7.png"/>
 </tile>
 <tile id="20">
  <image width="8" height="7" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Grass/8.png"/>
 </tile>
 <tile id="21">
  <image width="10" height="7" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Grass/9.png"/>
 </tile>
 <tile id="22">
  <image width="27" height="26" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Houses/6.png"/>
 </tile>
 <tile id="23">
  <image width="32" height="38" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Houses/1.png"/>
 </tile>
 <tile id="24">
  <image width="33" height="38" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Houses/2.png"/>
 </tile>
 <tile id="25">
  <image width="43" height="38" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Houses/3.png"/>
 </tile>
 <tile id="26">
  <image width="35" height="63" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Houses/4.png"/>
 </tile>
 <tile id="27">
  <image width="43" height="40" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Houses/5.png"/>
 </tile>
 <tile id="28">
  <image width="27" height="10" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Rocks/6.png"/>
 </tile>
 <tile id="29">
  <image width="39" height="47" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Rocks/1.png"/>
 </tile>
 <tile id="30">
  <image width="49" height="28" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Rocks/2.png"/>
 </tile>
 <tile id="31">
  <image width="53" height="35" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Rocks/3.png"/>
 </tile>
 <tile id="32">
  <image width="40" height="27" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Rocks/4.png"/>
 </tile>
 <tile id="33">
  <image width="39" height="25" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Rocks/5.png"/>
 </tile>
 <tile id="34">
  <image width="60" height="47" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Ruins/5.png"/>
 </tile>
 <tile id="35">
  <image width="32" height="31" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Ruins/1.png"/>
 </tile>
 <tile id="36">
  <image width="32" height="13" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Ruins/2.png"/>
 </tile>
 <tile id="37">
  <image width="32" height="27" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Ruins/3.png"/>
 </tile>
 <tile id="38">
  <image width="23" height="47" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Ruins/4.png"/>
 </tile>
 <tile id="39">
  <image width="15" height="22" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Trees/6.png"/>
 </tile>
 <tile id="40">
  <image width="27" height="44" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Trees/1.png"/>
 </tile>
 <tile id="41">
  <image width="23" height="38" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Trees/2.png"/>
 </tile>
 <tile id="42">
  <image width="28" height="32" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Trees/3.png"/>
 </tile>
 <tile id="43">
  <image width="27" height="39" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Trees/4.png"/>
 </tile>
 <tile id="44">
  <image width="26" height="38" source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/2 Objects/Trees/5.png"/>
 </tile>
</tileset>

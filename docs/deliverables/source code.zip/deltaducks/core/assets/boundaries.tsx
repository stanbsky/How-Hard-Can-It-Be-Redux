<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="fuck 2" tilewidth="32" tileheight="32" tilecount="16" columns="4">
 <image source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/4 Fog/Fog_tiles.png" width="128" height="128"/>
</tileset>

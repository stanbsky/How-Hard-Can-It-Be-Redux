<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="fuckin ocean 3" tilewidth="32" tileheight="32" tilecount="144" columns="12">
 <image source="craftpix-net-280167-free-level-map-pixel-art-assets-pack(1)/1 Tiles/Map_tiles.png" width="384" height="384"/>
</tileset>
